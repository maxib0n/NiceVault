# Archivio 2019

Tutto quello che c'era sul vecchio PC.
